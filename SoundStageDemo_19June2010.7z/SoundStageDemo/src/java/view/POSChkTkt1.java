/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package view;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.LinkedList;
import java.util.Iterator;
import java.sql.*;
import javax.servlet.RequestDispatcher;

public class POSChkTkt1 extends HttpServlet {
    List errmsg=null;
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        int count=0;
        errmsg=new LinkedList();
        String TicketID=(String)request.getParameter("TicketID");

        if(TicketID.equals(""))
        {
            errmsg.add("Enter valid Ticket ID.");
            request.setAttribute("errmsg",errmsg);
            RequestDispatcher rd=request.getRequestDispatcher("POSHome.jsp");
            rd.forward(request,response);
            return;
        }
        try
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:SoundStage1");

            String query="select * from tbTicket where TId='"+TicketID+"' ";
            stmt=con.prepareStatement(query);
            rs=stmt.executeQuery();
            out.println("<html><head><title>GenerateTicket</title><link href='StyleSheet1.css' type='text/css' rel='Stylesheet'/><link href='images/catmenu.css' type='text/css' rel='Stylesheet'/></head><body><div id='container'>");
            out.println("<div id='header'>");
            RequestDispatcher rd1=request.getRequestDispatcher("Header/Header.jsp");
            rd1.include(request, response);
            out.println("</div><br><br><br>");
            out.print("<div id='content' align='center'>");
            out.print("<br><h2>POS Administration Page</h2><br>" +
                    "<form action='POSChkTkt1' method='post'><h3>Generate Ticket</h3>Enter Ticket ID :<input type='text' name='TicketID'/><input type='submit' value='Check'/></form><div class='errmsg'>");
            if(request.getAttribute("errmsg")!=null)
            {
                out.println("<font color='red'><ul>");
                        List errTqt=(List)request.getAttribute("errmsg");
                        Iterator i=errTqt.iterator();
                        while(i.hasNext())
                        {
                            String s=(String)i.next();
                            out.println("<li>"+s+"</li>");
                        }
                        out.println("</ul>");
            }
            out.println("</font></div><font align=center size='10'><table style='text-align:center;'>");

            while(rs.next())
            {
                count++;
                out.println("<tr><td align='left'>Card No :</td><td align='left'>"+rs.getString(1)+"</td></tr>");
                out.println("<tr><td align='left'>Name :</td><td align='left'>"+rs.getString(2)+"</td></tr>");
                out.println("<tr><td align='left'>Ticket ID :</td><td align='left'>"+rs.getString(3)+"</td></tr>");
                out.println("<tr><td align='left'>Movie Dt :</td><td align='left'>"+rs.getString(4)+"</td></tr>");
                out.println("<tr><td align='left'>Seat No :</td><td align='left'>"+rs.getString(5)+"</td></tr>");
                out.println("<tr><td align='left'>Hall Code :</td><td align='left'>"+rs.getString(6)+"</td></tr>");
                out.println("<tr><td align='left'>Site Code :</td><td align='left'>"+rs.getString(7)+"</td></tr>");
                out.println("<tr><td align='left'>Movie Id :</td><td align='left'>"+rs.getString(8)+"</td></tr>");
                out.println("<tr><td align='left'>Movie Name :</td><td align='left'>"+rs.getString(9)+"</td></tr>");
                out.println("<tr><td align='left'>Show Time :</td><td align='left'>"+rs.getString(10)+"</td></tr>");
                out.println("<tr><td align='left'>Slot :</td><td align='left'>"+rs.getString(11)+"</td></tr>");
                out.println("<tr><td align='left'>Class :</td><td v>"+rs.getString(12)+"</td></tr>");
                out.println("<tr><td align='left'>Ticket Price :</td><td align='left'>"+rs.getString(13)+"</td></tr>");
                out.println("<tr><td align='left'>Combo :</td><td align='left'>"+rs.getString(14)+"</td></tr>");
                out.println("<tr><td align='left'>Combo Price :</td><td align='left'>"+rs.getString(15)+"</td></tr>");
                out.println("<tr><td align='left'>Total :</td><td align='left'>"+rs.getString(16)+"</td></tr>");


            }
            if(count==0)
            {
                 errmsg.add("Specified Ticket Number is INVALID..");
                request.setAttribute("errmsg",errmsg);
                RequestDispatcher rd=request.getRequestDispatcher("POSHome.jsp");
                rd.forward(request,response);
                return;
            }
            out.println("</table></font></br></br><a href='POSHome.jsp'>Back</a></div>");
            out.println("<div id='footer'>");
            rd1=request.getRequestDispatcher("Footer/Footer.jsp");
            rd1.include(request, response);
            out.println("</div></body></html>");
        }
        catch (SQLException se)
        {
            throw new RuntimeException("A database error occured. "+ se.getMessage());
        }
        catch(Exception e)
        {
            e.printStackTrace(System.err);
        }
        out.close();
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
