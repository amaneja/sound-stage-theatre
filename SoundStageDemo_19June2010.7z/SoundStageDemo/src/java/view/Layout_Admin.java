/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package view;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.ItemSelectable;
import java.io.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.List;
import java.util.Iterator;
import java.util.LinkedList;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Aman S. Aneja
 */
public class Layout_Admin extends HttpServlet {


    Connection connection = null;
    PreparedStatement stmt = null;
    ResultSet results = null;
    RequestDispatcher rd;

    int rows,cols;
    String hallcode,plan,ls,fg,slot,fslot,seatno,uSiteCode;

    List invalid=null;
    List silver=null;
    List gold=null;
    List booked=null;
    List bookedSeats=null;
    List ubookedSeats=null;
    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        response.setHeader("Cache-Control","no-cache"); //Forces caches to obtain a new copy of the page from the origin server
        response.setHeader("Cache-Control","no-store"); //Directs caches not to store the page under any circumstance
        response.setDateHeader("Expires", 0); //Causes the proxy cache to see the page as "stale"
        response.setHeader("Pragma","no-cache"); //HTTP 1.0 backward compatibility



        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession session=request.getSession();

        uSiteCode=(String)session.getAttribute("loc");
        plan=(String)session.getAttribute("plan");
        String Mdate=(String)session.getAttribute("mdate");
        String Mid=(String)session.getAttribute("mid");
        String Mtime=(String)session.getAttribute("mtime");
        String uclass=(String)session.getAttribute("uclass");
        String qty=(String)session.getAttribute("qty");
        hallcode=(String)session.getAttribute("hallcode");
        try
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            connection=DriverManager.getConnection("jdbc:odbc:SoundStage1");


//get Plan


//get rows
            String query2="Select * from tbPlan where PlanId='"+plan+"'";
            stmt=connection.prepareStatement(query2);
            results=stmt.executeQuery();
            while(results.next())
            {
            rows=Integer.parseInt(results.getString(2));
            }

//get columns
            String query3="Select * from tbPlan where PlanId='"+plan+"'";
            stmt=connection.prepareStatement(query3);
            results=stmt.executeQuery();
            while(results.next())
            {
            cols=Integer.parseInt(results.getString(3));
            }

            char rName[]={'n','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
            int cName[]=new int[cols];

//get Invalid Seats
            invalid=new LinkedList();
            String query4="Select * from "+plan+" where Status='invalid'";
            stmt=connection.prepareStatement(query4);
            results=stmt.executeQuery();
            while(results.next())
            {
            invalid.add(results.getString(1)+""+results.getString(2));
            }



//get Silver seats
            silver=new LinkedList();
            String query6="Select * from "+plan+" where Class='silver'";
            stmt=connection.prepareStatement(query6);
            results=stmt.executeQuery();
            while(results.next())
            {
            silver.add(results.getString(1)+""+results.getString(2));
            }

//get Gold seats
            gold=new LinkedList();
            String query7="Select * from "+plan+" where Class='gold'";
            stmt=connection.prepareStatement(query7);
            results=stmt.executeQuery();
            while(results.next())
            {
            gold.add(results.getString(1)+""+results.getString(2));
            }



            //resolve date
            String query9="select * from tbShows where StartTime='"+Mtime+"' and MovieId='"+Mid+"'";
            stmt=connection.prepareStatement(query9);
            results=stmt.executeQuery();
            while(results.next())
            {
                slot=(String)results.getString(3);
            }
            session.setAttribute("slot",slot);

            String query10="select "+slot+" from tbDateDef where Day='"+Mdate+"'";
            stmt=connection.prepareStatement(query10);
            results=stmt.executeQuery();
            while(results.next())
            {
               fslot=(String)results.getString(""+slot+"");
            }
            session.setAttribute("fslot",fslot);  // Get Slot Like 1Mo,2Mo,3E...

//get booked seats
            booked=new LinkedList();

            if(session.getAttribute("booked")!=null)
            {
                 booked=(List)session.getAttribute("booked");
            }

            String query8="select * from "+hallcode+" where ["+fslot+"]='no'";
            stmt=connection.prepareStatement(query8);
            results=stmt.executeQuery();
            while(results.next())
            {
            booked.add(results.getString(1));
            }

            session.setAttribute("booked",booked);

//get selected seats
            ubookedSeats=new LinkedList();
            if(session.getAttribute("ubookedSeats")!=null)
            ubookedSeats=(List)session.getAttribute("ubookedSeats");


//generate m x n matrix
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Theater Layout</title> <link href='StyleSheet1.css' type='text/css' rel='Stylesheet'/>");
            out.println("<script type='text/javascript'>");



                out.println("function check(evt)");
                out.println("{");
                out.println("var target = evt.srcElement || evt.target ;");
                out.println("var Unselected = '#00ff00' ;");
                out.println("var Selected = '#ff0000'");

                out.println("	if (target.bgColor == Selected)");
                out.println("	{");
                        // put cell back to unselected
                out.println("		target.bgColor = Unselected ;");
                        //document.getElementById("h" + target.id).value="USelect";
                out.println("	}");

                out.println("	else");
                out.println("	{");
                        out.println("target.bgColor = Selected ;");
                        //document.getElementById("h" + target.id).value="Select";
                    out.println("}");

                //document.write(document.getElementById("h" + target.id).value);
                out.println("}");



            out.println("</script>");
            out.println("</head>");
            out.println("<body>");
            out.println("<div id='container'>");
            out.println("<div id='header'");
            rd=request.getRequestDispatcher("Header/Header.jsp");
            rd.include(request, response);
            out.println("</div>");
            out.println("<div id='content'>");
            out.println("<center>");
            out.println("<form action='null' method='post'>");
            out.println("<table><br><br>");
            out.println("<tr><td align='center' colspan='25'><img src='images/screen.JPG'/><br><br><br><br><br><br></td></tr>");

                for(int r=1;r<=rows;r++)
                {
                    out.println("<tr><td>"+rName[r]+"</td>");
                    for(int c=1;c<=cols;c++)
                    {
                        String sp=""+r+""+c;
                        if(invalid.contains(sp))
                        {
                            out.println("<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>");
                        }
                        else
                        {

                            if(uclass.equals("Silver"))
                            {
                                if(silver.contains(sp))
                                {
                                    if(booked!=null)
                                    {
                                        if(booked.contains(sp))
                                        {
                                            if(ubookedSeats.contains(sp))
                                            {
                                            out.println("<td bgcolor='#00ff00'>"+r+c+"</td>");
                                            }
                                            else
                                            {
                                            out.println("<td><input name='Silver' type='button' value='"+r+""+c+"' id='booked'/></td>");
                                            }
                                        }
                                        else
                                        {
                                                out.println("<td bgcolor='#00ff00' id='td"+r+c+"' onclick='click(event,id)'>"+r+c+"</td>");

                                        }
                                    }
                                    else
                                    {
                                        out.println("<td><input name='Silver' class='silver' type='submit' value='"+r+""+c+"' id='available'/></td>");
                                    }
                                }
                                else
                                {
                                    out.println("<td><input type='button' value='"+r+""+c+"' class='gold' id='available'/></td>");
                                }
                            }

                            if(uclass.equals("Gold"))
                            {
                                if(gold.contains(sp))
                                {
                                    if(booked!=null)
                                    {
                                        if(booked.contains(sp))
                                        {
                                            if(ubookedSeats.contains(sp))
                                            {
                                            out.println("<td><input name='Gold' class='silver' type='submit' value='"+r+""+c+"' id='cbooked'/></td>");
                                            }
                                            else
                                            {
                                            out.println("<td><input name='Gold' type='button' value='"+r+""+c+"' id='booked'/></td>");
                                            }

                                        }
                                        else
                                        {
                                            out.println("<td><input type='submit' name='Gold' class='gold'  value='"+r+""+c+"' id='available'/></td>");
                                        }
                                    }
                                    else
                                    {
                                        out.println("<td><input name='Gold' class='gold' type='submit' value='"+r+""+c+"' id='available'/></td>");
                                    }
                                }
                                else
                                {
                                    out.println("<td><input type='button' class='silver' value='"+r+""+c+"'id='available'/></td>");
                                }
                            }
                        }
                    }
                out.println("</tr>");
               }




            out.println("</table><br>");
            out.println("<a href='ProceedServlet'>Proceed</a>");
            out.println("<br><br><br><hr size='5' width='80%' color='silver'><table id='info' cellpadding='5'><tr><td bgcolor='Red'><font color='black'>Booked seats</font></td><td bgcolor='green'><font color='black'>Selected seats</font></td><td bgcolor='silver'><font color='black'>Silver Seats</font></td><td bgcolor='gold'><font color='black'>Gold seats</font></td></tr></table></hr></font>");

            out.println("</div>");
            out.println("</center></div>");

            out.println("<div id='footer'>");
            rd=request.getRequestDispatcher("Footer/Footer.jsp");
            rd.include(request, response);
            //out.println("</center><br><br><center><div id='footer'><hr size='3' color='silver' width='100%'/><div><a href=''>Careers</a> | <a href='' >About Us</a> | <a href='' >Investors</a> | <a href=''>Partners</a> | <a href=''> Our Policies</a> <a href=''>Feedback</a> | <a href=''>FAQs</a> | <a href=''>Site Map</a> | <a href=''>Blog</a><br><br>Copyright (c) SS.com. All rights reserved. Design by SSC.</div></div></center></body>");
            out.println("</div>");
            out.println("</body>");
            out.println("</html>");
            out.println();
        }
        catch (SQLException se)
        {
            throw new RuntimeException("A database error occured. "+ se.getMessage());
        }
        catch(Exception e)
        {
            e.printStackTrace(System.err);
        }

        out.close();

    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
