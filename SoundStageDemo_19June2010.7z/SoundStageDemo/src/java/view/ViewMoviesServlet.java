/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;


public class ViewMoviesServlet extends HttpServlet
{
    Connection con;
    PreparedStatement stmt;
    ResultSet rs;

    String query;
   

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:SoundStage1");

            query="select * from tbMovies";
            stmt=con.prepareStatement(query);
            rs=stmt.executeQuery();

            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ViewMoviesServlet</title>");
            out.println("<link href='StyleSheet1' type='text/css' rel='Stylesheet'/>");
            out.println("</head>");
            out.println("<body>");
            out.println("<table>");

            while(rs.next())
            {
                out.println("<tr><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td><td>"+rs.getString(5)+"</td><td>"+rs.getString(6)+"</td></tr>");
            }

       
            out.println("</table>");
            out.println("</body>");
            out.println("</html>");
            

        }
        catch (ClassNotFoundException ex)
        {
            out.print(ex.getException());
        }
        catch (SQLException sqlex)
        {
           out.print(sqlex.getMessage());
        }
        catch(Exception ex)
        {
            ex.printStackTrace();

        }
        finally
        {
            out.close();
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
