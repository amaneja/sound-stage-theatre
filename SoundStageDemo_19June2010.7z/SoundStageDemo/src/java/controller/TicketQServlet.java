/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.util.List;
import java.util.Iterator;
import java.util.LinkedList;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;

import model.SnacksService;


public class TicketQServlet extends HttpServlet {

    String uclass,tqty,TicketAmt,fgrandtotal;
    String snacksrate;
    List errTqt=null;
    String comboplans=null;
    int grandtotal;
    List selectedSeats=null;
    int ticketprice,snacksprice=0;
   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        String combo[];
        String sqty[];

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
        HttpSession session=request.getSession();
        errTqt=new LinkedList();

        TicketAmt=request.getParameter("TicketAmt");
        uclass=request.getParameter("UserClass");
        tqty=request.getParameter("Qty");



        combo=request.getParameterValues("combo");
        sqty=request.getParameterValues("sQty");

        if(uclass.equals("0"))
        {
            errTqt.add("Select a class");
        }
        if(tqty.equals("0"))
        {
            errTqt.add("Enter no.of tickets");
        }
        if(!errTqt.isEmpty())
        {
            request.setAttribute("errTqt",errTqt);
            RequestDispatcher rd=request.getRequestDispatcher("TicketQty.jsp");
            rd.forward(request,response);
            return;
        }

        if((combo!=null)&&(sqty!=null))
        {
        SnacksService ss=new SnacksService();
        snacksrate=""+ss.getRate(combo,sqty);
        comboplans=(String)ss.getComboPlans();

        ticketprice=Integer.parseInt(TicketAmt);
        snacksprice=Integer.parseInt(snacksrate);
        grandtotal=ticketprice+snacksprice;
        fgrandtotal=""+grandtotal;
        }
        else
        {
            ticketprice=Integer.parseInt(TicketAmt);
            comboplans="Not Availed";
            snacksrate="Not Availed";
            grandtotal=ticketprice;
            fgrandtotal=""+ticketprice;
        }



            session.setAttribute("grandtotal",fgrandtotal);
            session.setAttribute("uclass",uclass);     // User Selected Class
            session.setAttribute("qty",tqty);           // User Selected Qty
            session.setAttribute("TicketAmt",TicketAmt); // TicketAmt
            session.setAttribute("srate",snacksrate);
            session.setAttribute("comboplan",comboplans);

        RequestDispatcher rd=request.getRequestDispatcher("Layout");
        rd.forward(request,response);

        }

        finally
        {
            out.close();
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
