/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import java.io.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.List;
import java.util.LinkedList;
import java.sql.*;
import java.util.Iterator;
import javax.servlet.http.HttpSession;

public class TicketSummary extends HttpServlet
{
    String tid,cno,cname,cvv,expdate;
   List errmsg=null;
   List selectedSeats=null;
   String qbookseats="";



    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();

        Connection con;
        PreparedStatement smt;
        Statement stmt;
        ResultSet rs;

        String tdate = (String)session.getAttribute("date");
        String seatname = (String)session.getAttribute("seatname");
        String hallcode = (String)session.getAttribute("hallcode");
        String sitecode = (String)session.getAttribute("location");
        String movieid = (String)session.getAttribute("mid");
        String movie = (String)session.getAttribute("mname");
        String showtiming = (String)session.getAttribute("mtime");
        String slot = (String)session.getAttribute("slot");
        String uclass = (String)session.getAttribute("uclass");
        String price = (String)session.getAttribute("TicketAmt");
        String comboplan=(String)session.getAttribute("comboplan");
        String snacksrate=(String)session.getAttribute("srate");
        String grandtotal=(String)session.getAttribute("grandtotal");
        String fslot=(String)session.getAttribute("fslot");



        cno=(String)request.getParameter("crdn");
        cname=(String)request.getParameter("name");
        cvv=(String)request.getParameter("cvv");
        expdate=(String)request.getParameter("expdt");

        errmsg= new LinkedList();
        if(cno.equals("") || cno.length()<16 || cno.length()>16)
        {
            errmsg.add("Enter valid credit card no.");
        }
        if(cname.equals(""))
        {
            errmsg.add("Please specify a card name.");
        }
        if(expdate.equals(""))
        {
            errmsg.add("Enter valid expiry date!!");
        }
        if(cvv.equals("") || cvv.length()<3 || cvv.length()>3)
        {
            errmsg.add("Enter valid CVV code!!");
        }

        if(!errmsg.isEmpty())
        {
            request.setAttribute("errmsg",errmsg);
            RequestDispatcher rd= request.getRequestDispatcher("Summary.jsp");
            rd.forward(request,response);
            return;
        }

        try
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con = DriverManager.getConnection("jdbc:odbc:SoundStage1");

            String query = "select * from tbTicket";
            smt=con.prepareStatement(query);
            rs=smt.executeQuery();
            while(rs.next())
            {
                tid=rs.getString(3);
            }

            String s = tid;
            String s1 = s.substring(1);
            int i=Integer.parseInt(s1);
            i++;
            s1=""+i;
            tid="T"+s1;



          //  tid=tid + 1;

            String query1 = "insert into tbTicket values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            smt=con.prepareStatement(query1);
            smt.setString(1,cno);
            smt.setString(2,cname);
            smt.setString(3,tid);
            smt.setString(4,tdate);
            smt.setString(5,seatname);
            smt.setString(6,hallcode);
            smt.setString(7,sitecode);
            smt.setString(8,movieid);
            smt.setString(9,movie);
            smt.setString(10,showtiming);
            smt.setString(11,slot);
            smt.setString(12,uclass);
            smt.setString(13,price);
            smt.setString(14,comboplan);
            smt.setString(15,snacksrate);
            smt.setString(16,grandtotal);

            //book selected seats
            selectedSeats=new LinkedList();
            selectedSeats=(List)session.getAttribute("ubookedSeats");

            Iterator items=selectedSeats.iterator();

            while(items.hasNext())
            {
                 qbookseats="update "+hallcode+" set "+fslot+"='no' where SeatMapping='"+items.next()+"' ";
                 stmt=con.createStatement();
                 stmt.executeUpdate(qbookseats);
            }




            int iadd=smt.executeUpdate();
            request.setAttribute("tid",tid);
            RequestDispatcher v=request.getRequestDispatcher("ThankYou.jsp");
            v.forward(request,response);
        }
        catch(SQLException ex)
        {
            out.println("database error"+ex);
        }
        catch(Exception ex)
        {
            out.println(ex);
        }

        out.close();
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
