/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import java.io.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.List;
import java.util.Iterator;
import java.util.LinkedList;
import javax.servlet.http.HttpSession;

public class ProceedServlet extends HttpServlet
{
  String seatno,seatname,screen;
    Connection connection = null;
    PreparedStatement stmt = null;
    ResultSet results = null;
    List ubookedSeats=null;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
    {
        try
        {

         Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
         connection=DriverManager.getConnection("jdbc:odbc:SoundStage1");

        HttpSession session=request.getSession();
        String hallcode=(String)session.getAttribute("hallcode");



        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

         if(session.getAttribute("ubookedSeats")==null)
            {
                out.println("Please select your seats first.<a href='Layout'>Back</a>");
                return;
            }

        ubookedSeats=new LinkedList();
        ubookedSeats=(List)session.getAttribute("ubookedSeats");

         Iterator seatItems=ubookedSeats.iterator();

         seatname="";

            while(seatItems.hasNext())
            {
                seatno=(String)seatItems.next();
                String query11="select * from "+hallcode+" where SeatMapping='"+seatno+"'";
                stmt=connection.prepareStatement(query11);
                results=stmt.executeQuery();

                 while(results.next())
                {
                    seatname=seatname+" "+results.getString(4)+" ";
                }

            }

         String q="select * from tbMovieTheater where HallCode= '"+hallcode+"'";
         stmt=connection.prepareStatement(q);
            results=stmt.executeQuery();
            while(results.next())
            {
                screen=results.getString(5);
            }

         session.setAttribute("seatname",seatname);
         session.setAttribute("screen",screen);


        int Fcount=Integer.parseInt((String) session.getAttribute("Fcount"));
        int qty=Integer.parseInt((String) session.getAttribute("qty"));
        if(session.getAttribute("Fcount")==null)
        {
            Fcount=0;
        }
        else
        {
             Fcount=Integer.parseInt((String) session.getAttribute("Fcount"));
        }


        if (Fcount<qty)
        {
             out.println("Please select "+qty+" seats.<a href='Layout'>Back</a>");

        }
        else
        {
            RequestDispatcher rd=request.getRequestDispatcher("Summary.jsp");
            rd.forward(request,response);
        }
        out.close();
    }
      catch (SQLException se)
    {
            throw new RuntimeException("A database error occured. "+ se.getMessage());
     }
     catch(Exception e)
     {
            e.printStackTrace(System.err);
      }
    }


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
