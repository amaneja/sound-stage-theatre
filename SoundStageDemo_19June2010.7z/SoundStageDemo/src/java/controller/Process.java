/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import java.io.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.List;
import java.util.Iterator;
import java.util.LinkedList;
import javax.servlet.http.HttpSession;

public class Process extends HttpServlet
{
    List bookedSeats=null;
    String seat;
    int counter=1,fcount;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession session=request.getSession();
        List booked=new LinkedList();
        List ubookedSeats=new LinkedList();

        String uclass=(String)session.getAttribute("uclass");
        int qty=Integer.parseInt((String) session.getAttribute("qty"));

        if(session.getAttribute("count")==null)
        {
            counter=1;
            String c=""+counter;
            session.setAttribute("count",c);
        }
        else
        {
            counter=counter+1;
            String c=""+counter;
            session.setAttribute("count",c);
        }

        int fcount=Integer.parseInt((String)session.getAttribute("count"));

        String Fcount=""+fcount;
        session.setAttribute("Fcount",Fcount);

        if(fcount<=qty)
        {
            if(session.getAttribute("booked")!=null)
            {
                booked=(List)session.getAttribute("booked");
            }
            if(session.getAttribute("ubookedSeats")!=null)
            {
                ubookedSeats=(List)session.getAttribute("ubookedSeats");
            }
            if(uclass.equals("Silver"))
            {
                seat=(String)request.getParameter("Silver");
            }
            if(uclass.equals("Gold"))
            {
                seat=(String)request.getParameter("Gold");
            }

            ubookedSeats.add(seat);
            booked.add(seat);

            session.setAttribute("booked",booked);
            session.setAttribute("ubookedSeats",ubookedSeats);

            RequestDispatcher rd=request.getRequestDispatcher("Layout");
            rd.forward(request,response);
        }
        else
        {
            out.println("You have selected more than the prescribed no of tickets!! <br><center><a href='Layout'>back</a></center>");
        }


    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}