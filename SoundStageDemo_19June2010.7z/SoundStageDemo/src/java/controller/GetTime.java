/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.*;

public class GetTime extends HttpServlet {

    List errmsg = null;
    List errBlank=null;
    String uLocation,uMovie,uDate,add,cont;
    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session=request.getSession();

        String location=request.getParameter("location").trim();
        String movie=request.getParameter("movie").trim();
        String date=request.getParameter("date").trim();

        errBlank=new LinkedList();
        if(location.equals("0"))
        {
            errBlank.add("Select your location.");
        }
        if(movie.equals("0"))
        {
            errBlank.add("Select your movie.");
        }
        if(date.equals("0"))
        {
            errBlank.add("Select your movie date.");
        }
        if(!errBlank.isEmpty())
        {
            request.setAttribute("errBlank",errBlank);
            RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
            rd.forward(request,response);
            return;
        }

        Connection connection = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String qsitecode="Select * from tbSite where SiteLocation='"+location+"'";
        String qmovieid="Select * from tbMovies where Movie='"+movie+"'";
        String qdate="Select * from tbDateDef where DDate='"+date+"'";

        try {

            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            connection = DriverManager.getConnection("jdbc:odbc:SoundStage1");

            stmt = connection.prepareStatement(qsitecode);
            rs=stmt.executeQuery();
            while(rs.next())
            {
                uLocation=rs.getString(1);
                add=rs.getString(3);
                cont=rs.getString(4);
            }

            stmt = connection.prepareStatement(qmovieid);
            rs=stmt.executeQuery();
            while(rs.next())
            {
                uMovie=rs.getString(1);
            }

            stmt = connection.prepareStatement(qdate);
            rs=stmt.executeQuery();
            while(rs.next())
            {
                uDate=rs.getString(1);
            }

            String getDatequery="Select * from tbShows where MovieId='"+uMovie+"' and SiteCode='"+uLocation+"'";
            stmt = connection.prepareStatement(getDatequery);

            List uMovieTimes=new LinkedList();
            rs=stmt.executeQuery();
            while(rs.next())
            {
                uMovieTimes.add(rs.getString(4));
            }

            session.setAttribute("cont",cont);
            session.setAttribute("add",add);
            session.setAttribute("location",location); // User Selected Location Like Mumbai
            session.setAttribute("loc",uLocation);     // SiteCode of Movie Like (1)
            session.setAttribute("mname",movie);      // User Selected Movie Name
            session.setAttribute("mid",uMovie);        // Movie ID
            session.setAttribute("date",date);         // User Selected Date
            session.setAttribute("mdate",uDate);       // Day Like Day1 or Day2
            session.setAttribute("movietimes",uMovieTimes);   // Available Movie Time

            RequestDispatcher rd1=request.getRequestDispatcher("SelectTime.jsp");
            rd1.forward(request,response);
            
        }
        catch (SQLException ex)
        {
            throw new RuntimeException("A database error occured. "+ ex.getMessage());
        }

        catch(Exception ex)
        {
            ex.printStackTrace(System.err);
        }

        finally {
            out.close();
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
