/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;


import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.util.List;
import java.util.Iterator;
import java.util.LinkedList;
import javax.servlet.RequestDispatcher;

/**
 *
 * @author student
 */
public class checkadminlogin extends HttpServlet {
     List errmsg;
    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {


        Connection connection;
        PreparedStatement stmt;
        ResultSet results;
        String query="select * from tbAdmin";
        String username=(String)request.getParameter("uname");
        String password=(String)request.getParameter("upass");

        errmsg=new LinkedList();

        if(username.equals("") || password.equals(""))
        {
            errmsg.add("Please enter the details!");
            request.setAttribute("err",errmsg);
            RequestDispatcher rd=request.getRequestDispatcher("AdminLogin.jsp");
            rd.forward(request,response);
            return;
        }
        try
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            connection = DriverManager.getConnection("jdbc:odbc:SoundStage1");

            stmt = connection.prepareStatement(query);
            results = stmt.executeQuery();

            while ( results.next() )
            {
                if(username.equals(results.getString(1)) && password.equals(results.getString(2)))
                {
                    RequestDispatcher rd=request.getRequestDispatcher("AdminHome.jsp");
                    rd.forward(request,response);
                }
                else
                {
                    errmsg.add("Invalid Username/Password");
                    request.setAttribute("err",errmsg);
                    RequestDispatcher rd=request.getRequestDispatcher("AdminLogin.jsp");
                    rd.forward(request,response);
                }
            }
        }
        catch (SQLException se)
        {
            throw new RuntimeException("A database error occured. "+ se.getMessage());
        }
        catch(Exception e)
        {
            e.printStackTrace(System.err);
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
