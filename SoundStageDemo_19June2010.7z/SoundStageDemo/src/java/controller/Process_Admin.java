/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import java.io.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.List;
import java.util.LinkedList;
import java.sql.*;
import java.util.Iterator;
import javax.servlet.http.HttpSession;


/**
 *
 * @author Aman S. Aneja
 */
public class Process_Admin extends HttpServlet {
   String sid,status;

        Connection con;
        PreparedStatement smt;
        Statement stmt;
        ResultSet rs;
    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();

        sid= (String) session.getAttribute("sid");//request.getParameter("td1");
        status= (String) session.getAttribute("status");


        try
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con= DriverManager.getConnection("jdbc:odbc:SoundStage1");



            String query1 = "insert into temp values(?,?)";
            smt=con.prepareStatement(query1);
            smt.setString(1,sid);
            smt.setString(2,status);
            int iadd=smt.executeUpdate();
    }

                catch(SQLException ex)
        {
            out.println("database error"+ex);
        }
        catch(Exception ex)
        {
            out.println(ex);
        }

        out.close();
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
