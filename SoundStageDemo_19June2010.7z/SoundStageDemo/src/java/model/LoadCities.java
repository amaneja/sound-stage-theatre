/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;
import java.util.List;
import java.util.LinkedList;
import java.util.Iterator;
import java.sql.*;

public class LoadCities {
    List cities=null;
    Connection con=null;

    Statement stmt=null;
    ResultSet rs=null;
    public List getCities()
    {
        cities=new LinkedList();
        String query="select * from tbSite";
        try
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:SoundStage1");

            stmt=con.createStatement();
            rs=stmt.executeQuery(query);
            while(rs.next())
            {
                cities.add(rs.getString(2));
            }
        }
        catch (ClassNotFoundException ex)
        {
            ex.printStackTrace();
        }
        catch (SQLException ex)
        {
            ex.printStackTrace();
        }

        return cities;
    }

}
