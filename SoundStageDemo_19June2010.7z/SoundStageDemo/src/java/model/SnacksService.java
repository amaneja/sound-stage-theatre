/*
 * SnacksService.java
 *
 * Created on 02 February 2010, 00:03
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package model;
import java.sql.*;
import java.util.List;
import java.util.Iterator;
import java.util.LinkedList;
/**
 *
 * @author Administrator
 */
public class SnacksService 
{
    String comboplans="";
    private String combo[];
    private String qty[];
    int sqty,rate,frate;
    String query;
    
    Connection con=null;
    Statement stmt=null;
    ResultSet rs=null;
    
    /** Creates a new instance of SnacksService */
    public SnacksService() 
    {
    }
    
    public int getRate(String combo[],String qty[])
    {
        try 
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con= DriverManager.getConnection("jdbc:odbc:SoundStage1");

            for(int i=0;i<=combo.length-1;i++)
            {
                query="select * from tbSnacks where MealPlan='"+combo[i]+"'";
                stmt=con.createStatement();
                rs=stmt.executeQuery(query);
                while(rs.next())
                {
                comboplans=comboplans +" "+ rs.getString(2)+",";
                rate=Integer.parseInt(rs.getString(4));
                }
                sqty=Integer.parseInt(qty[i]);
                frate=frate+(rate*sqty);
            }
                  
        } 
        catch (ClassNotFoundException ex) 
        {
            ex.printStackTrace();
        }
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return frate;
    }
    
    public String getComboPlans()
    {
            return comboplans;
    }
}
