package model;

import java.util.List;
import java.util.LinkedList;
import java.util.Iterator;
import java.sql.*;

public class LoadDate 
{
    List date=null;
    List site=null;

    Connection con=null;
    Statement stmt=null;
    ResultSet rs=null;

    /** Creates a new instance of LoadMovies */
    public LoadDate() 
    {
    }

    public List getDate()
    {
        date=new LinkedList();
        String query="select * from tbDateDef";
        try 
        {            
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con= DriverManager.getConnection("jdbc:odbc:SoundStage1");

            stmt=con.createStatement();
            rs=stmt.executeQuery(query);

            while(rs.next())
            {
                date.add(rs.getString(2));
            }           
        } 
        catch (ClassNotFoundException ex) 
        {
            ex.printStackTrace();
        }
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }       
        return date;
    }

    public List getSite()
    {
        site = new LinkedList();
        String Query="select * from tbSite";
        try
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:SoundStage1");

            stmt=con.createStatement();
            rs=stmt.executeQuery(Query);

            while(rs.next())
            {
                site.add(rs.getString(2));
            }
        }
        catch (ClassNotFoundException ex) 
        {
        ex.printStackTrace();
        }
        catch (SQLException ex) 
        {
        ex.printStackTrace();
        }              
        return site;        
    }
}