package model;

import java.util.List;
import java.util.LinkedList;
import java.util.Iterator;
import java.sql.*;

public class LoadMovies 
{
    List cities=null;
    List movies=null;
    List movieid=null;
    List time=null;
    String Movie;
    Connection con=null;

    Statement stmt=null;
    ResultSet rs=null;

    /** Creates a new instance of LoadMovies */
    public LoadMovies() 
    {
    }

    public List getMovies()
    {
        movies=new LinkedList();
        String query="select * from tbMovies";
        try 
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con= DriverManager.getConnection("jdbc:odbc:SoundStage1");

            stmt=con.createStatement();
            rs=stmt.executeQuery(query);

            while(rs.next())
            {
                movies.add(rs.getString(2));
            }           
        } 
        catch (ClassNotFoundException ex) 
        {
            ex.printStackTrace();
        }
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }

        return movies;
    }

    
    

    public List getMovieID()
    {
        movieid=new LinkedList();
        String query1="select * from tbMovies";
        try 
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con= DriverManager.getConnection("jdbc:odbc:SoundStage1");

            stmt=con.createStatement();
            rs=stmt.executeQuery(query1);

            while(rs.next())
            {
                movieid.add(rs.getString(1));
                movieid.add(rs.getString(2));
            }           
        } 
        catch (ClassNotFoundException ex) 
        {
            ex.printStackTrace();
        }
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }      
        return movieid;
    }

    public List getTime() 
    {
        time = new LinkedList();
        String qry="select * from tbShows where MovieId='M5'";
        try
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:SoundStage1");

            stmt =con.createStatement();
            rs=stmt.executeQuery(qry);
            while(rs.next())
            {
                time.add(rs.getString(4));
            }
        }
        catch(ClassNotFoundException ex)
        {
            ex.printStackTrace();
        }
        catch(SQLException ex)
        {
            ex.printStackTrace();
        }
        return time;
    }
}