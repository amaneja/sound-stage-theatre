function Calculate(form)
            {
             var qty=eval(form.Qty.value);
             var srate=eval(form.silver.value);
             var grate=eval(form.gold.value);
             var amt;
             
                if(form.Class[0].checked==true)
                {
                    amt=qty*srate;
                    form.TicketAmt.value=amt;
                    form.UserClass.value="Silver";
                }
                if(form.Class[1].checked==true)
                {
                    amt=qty*grate;
                    form.TicketAmt.value=amt;
                     form.UserClass.value="Gold";
                }
                if((form.Class[0].checked==false) && (form.Class[1].checked==false ))
                {
                    alert("Select Class!!");
                }
            }  