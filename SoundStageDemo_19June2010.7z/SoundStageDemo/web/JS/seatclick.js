/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

out.println("function check(evt)");
out.println("{");
out.println("var target = evt.srcElement || evt.target ;");
out.println("var Unselected = '#00ff00' ;");
out.println("var Selected = '#ff0000'");

out.println("	if (target.bgColor == Selected)");
out.println("	{");
		// put cell back to unselected
out.println("		target.bgColor = Unselected ;");
		//document.getElementById("h" + target.id).value="USelect";
out.println("	}");

out.println("	else");
out.println("	{");
		out.println("target.bgColor = Selected ;");
		//document.getElementById("h" + target.id).value="Select";
	out.println("}");

//document.write(document.getElementById("h" + target.id).value);
out.println("}");


